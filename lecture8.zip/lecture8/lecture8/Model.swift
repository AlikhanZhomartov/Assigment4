//
//  Model.swift
//  lecture8
//
//  Created by admin on 08.02.2021.
//

import Foundation


public struct Model: Codable{
    let weather: [Weather]?
    let main: MainRes?
    let name: String?
}

struct MainRes: Codable {
    let temp: Double?
    let feels_like: Double?
}

struct Weather: Codable {
    let main: String?
    let description: String?
}


