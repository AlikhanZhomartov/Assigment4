//
//  ViewController.swift
//  lecture8
//
//  Created by admin on 08.02.2021.
//

import UIKit
import Alamofire

class ViewController: UIViewController {
    
    @IBOutlet weak var cityName: UILabel!
    @IBOutlet weak var temp: UILabel!
    @IBOutlet weak var feelsLikeTemp: UILabel!
    @IBOutlet weak var desc: UILabel!
    
    let url = Constants.host + "?q=\(Constants.city)&appid=\(Constants.apiKey)&units=metric"
    var myData: Model?
    
    private var decoder: JSONDecoder = JSONDecoder()

    override func viewDidLoad() {
        super.viewDidLoad()
        fetchData()
    }
    
    
    func updateUI(){
        cityName.text = myData?.name
        temp.text = "\(String(myData?.main?.temp ?? 0.0)) °C"
        feelsLikeTemp.text = "\(String(myData?.main?.feels_like ?? 0.0)) °C"
        desc.text = myData?.weather?.first?.description
    }
    
    func fetchData(){
        AF.request(url).responseJSON { (response) in
            switch response.result{
            case .success(_):
                guard let data = response.data else { return }
                do{
                    let answer = try? self.decoder.decode(Model.self, from: data)
                    self.myData = answer
                    self.updateUI()
                }catch{
                    print("Parsing error")
                }
            case .failure(let err):
                print(err.errorDescription ?? "")
            }
        }
    }
    
}

