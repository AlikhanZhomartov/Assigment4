//
//  Constants.swift
//  lecture8
//
//  Created by admin on 09.02.2021.
//

import Foundation

struct Constants {
    static let host = "https://api.openweathermap.org/data/2.5/weather"
    static let city = "Astana"
    static let apiKey = ""
}
